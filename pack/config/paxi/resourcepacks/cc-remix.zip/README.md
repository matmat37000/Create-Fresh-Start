# CC Remix

This is a remix of the original…
- [Unnamed CC Resource Pack](https://modrinth.com/resourcepack/uccrp)
by Soumeh.
- [Create-like textures for ComputerCraft](https://modrinth.com/resourcepack/computercreate) by ascpial and im-hyps
- [CC: Mono](https://modrinth.com/resourcepack/cc-mono) by worldwidepixel

**Unnamed CC Resource Pack** and **Create-like textures for ComputerCraft** are licensed under the [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/deed.en) license, **CC: Mono** is licensed under the [Mozilla Public License 2.0](https://www.mozilla.org/en-US/MPL/2.0/)

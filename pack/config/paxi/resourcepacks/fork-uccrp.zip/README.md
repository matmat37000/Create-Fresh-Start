# Unnamed CC Resource Pack

This is a remix of the original [Unnamed CC Resource Pack](https://modrinth.com/resourcepack/uccrp)
by Soumeh.

It can be found under the [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/deed.en) license.
